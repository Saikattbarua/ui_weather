package com.example.counter_clock

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
